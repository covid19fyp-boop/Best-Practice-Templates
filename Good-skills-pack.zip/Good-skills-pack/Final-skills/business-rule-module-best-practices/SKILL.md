---
name: business-rule-module-best-practices
description: Design and enforce business-rule modules with clear ownership in a FastAPI modular monolith. Use when creating or refactoring domain invariants, moving rule logic out of API handlers/services, defining rule evaluation order and conflict behavior, mapping rule failures to stable API contracts, preventing duplicated business logic across modules, or adding rule-focused unit/integration tests and rollout gates.
---

# Business Rule Module Best Practices

Follow this workflow when building or reviewing business-rule modules.

## 1) Lock Capability Ownership First

- Assign each business rule set to one owner module under `backend/app/modules/<module>/domain/`.
- Define responsibilities and non-responsibilities before coding.
- Reuse owner-module logic through service contracts; do not copy-paste rule logic across modules.

Read `references/domain-rule-design-and-ownership.md`.

## 2) Classify Rules By Layer

- Keep transport/input validation in schema and API boundary layers.
- Keep domain invariants and decision logic in domain layer.
- Keep use-case sequencing and integration orchestration in service layer.
- Keep irreducible integrity guarantees in PostgreSQL constraints and transactional boundaries.

Read `references/fastapi-service-domain-boundary.md`.
Read `references/postgres-invariant-enforcement.md`.

## 3) Design Explicit Domain Contracts

- Accept explicit command/value inputs instead of framework objects.
- Return rule outcomes as domain-native results or errors, not HTTP responses.
- Standardize rule failure codes for deterministic API mapping and test coverage.

## 4) Keep API And Service Layers Thin

- API handlers translate DTOs and call service methods only.
- Service layer orchestrates repositories and domain decisions without duplicating rule logic.
- Do not import FastAPI request/response primitives into domain rule modules.

Read `references/fastapi-service-domain-boundary.md`.

## 5) Enforce Hard Invariants At The Data Boundary

- Back critical invariants with `CHECK`, `UNIQUE`, foreign keys, and partial indexes where appropriate.
- Use transactions and locking patterns for race-sensitive rules.
- Roll out stricter constraints with expand -> migrate -> contract when data backfill is required.

Read `references/postgres-invariant-enforcement.md`.

## 6) Verify Rule Behavior Before Release

- Unit-test domain invariants and decision branches.
- Integration-test transactional behavior, constraint failures, and concurrency edge cases.
- Contract-test API error mapping and compatibility behavior.
- Execute Dockerized validation gates before merge.

Read `references/testing-and-rollout-gates.md`.

## 7) Record Evidence And Rollback Notes

- Write task evidence under `docs/tasks/` with required governance headings.
- Document module boundary decisions in architecture docs/ADR when ownership changes.
- Capture rollback posture for rule or constraint changes.

For canonical references and update checks, read `references/official-sources.md`.
