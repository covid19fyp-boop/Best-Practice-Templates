# Postgres Invariant Enforcement

## Pair Application Rules With Data Constraints

- Keep business-rule logic in domain layer, but enforce critical invariants in PostgreSQL.
- Use database constraints to prevent bypass through race conditions or alternate write paths.

## Recommended Constraint Patterns

- `CHECK` constraints for value-range and state-shape guarantees.
- `UNIQUE` constraints or partial unique indexes for active-record uniqueness.
- Foreign keys for ownership and referential integrity.
- Exclusion constraints when interval overlap rules are strict.

## Concurrency And Transactions

- Use transactions for multi-step rule checks + writes.
- Use row-level locks when rule correctness depends on concurrent updates.
- Keep transactions short to reduce lock contention and deadlock risk.

## Migration Safety For New Constraints

- Prefer expand -> migrate -> contract:
  1. add nullable/backward-compatible structures,
  2. backfill and tighten reads/writes,
  3. enforce stricter constraints after data is compliant.
- Always define rollback posture for risky DDL and constraint changes.
