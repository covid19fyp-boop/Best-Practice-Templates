# Testing And Rollout Gates

## Test Portfolio For Business Rules

- Unit tests: rule predicates, invariant failures, decision ordering, edge conditions.
- Integration tests: transaction behavior, database constraint failures, idempotency, and race cases.
- Contract tests: deterministic mapping from domain failure code -> API error response.

## High-Risk Cases To Cover

- Concurrent writes that target same business key.
- Rule changes that alter eligibility outcomes.
- Backward compatibility for clients consuming existing error payloads.
- Migration windows where old/new rule paths coexist.

## Dockerized Verification Pattern

- Run backend lint and tests through Docker services.
- Run task evidence validation before completion.
- Run local CI fast gate when applicable:
  - `powershell -ExecutionPolicy Bypass -File infra/scripts/ci/validate-all.ps1 -Fast -AllowMissingOpenApiBaseline`

## Release Notes And Rollback

- Record changed rule semantics and expected behavior differences.
- State rollback strategy: code rollback, feature-flag rollback, or forward-fix with compatibility path.
- Track technical debt items when temporary compatibility branches are introduced.
