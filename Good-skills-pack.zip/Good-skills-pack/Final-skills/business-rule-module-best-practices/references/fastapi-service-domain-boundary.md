# FastAPI Service Domain Boundary

## Boundary Responsibilities

- `api/`: parse/validate transport DTOs, authorize request, call service, map output contract.
- `service/`: orchestrate use-case flow, transactions, repository access, and domain rule calls.
- `domain/`: evaluate business decisions and invariants with framework-light code.
- `repo/`: persistence adapters only; no hidden domain-policy branching.

## Keep Domain Logic Framework-Light

- Avoid FastAPI request/response imports in `domain/`.
- Avoid direct dependency on ORM session lifecycle in pure rule evaluators.
- Pass only required domain inputs (values, identities, timestamps, policy flags).

## Rule Failure Mapping

- Return domain error types/codes from service boundary.
- Map domain errors to HTTP contract in API layer consistently.
- Keep mapping stable across versions and cover in contract tests.

## Dependency Injection Guidance

- Use FastAPI dependencies for auth context, tenant/module context, and infra services.
- Treat caller context from trusted dependencies as input to domain decision methods.
- Do not use raw client-controlled headers as authorization source of truth.
