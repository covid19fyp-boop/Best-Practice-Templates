# Domain Rule Design And Ownership

## Rule Taxonomy

- **Invariant rules**: must always be true for valid domain state.
- **Decision rules**: derive outcomes from current state and input.
- **Policy rules**: role/time/context-dependent constraints that can evolve.
- **Process rules**: step order and orchestration constraints across components.

## Ownership Contract

- Assign one module as the source of truth for each rule family.
- Keep rule implementations inside the owner module `domain/` layer.
- Expose rule usage through owner service contracts, not direct cross-module repository writes.
- Reject new helper functions when equivalent rule logic already exists elsewhere in repo.

## Practical Module Checklist

- Define inputs and outputs for each business rule explicitly.
- Keep a deterministic rule-evaluation order for multi-rule decisions.
- Separate hard-stop violations from warnings/non-blocking advice.
- Keep failure codes stable so API and frontend consumers can map behavior safely.

## Duplication Control

- Search repository before introducing a new rule helper.
- If similar behavior exists in multiple modules, consolidate to one owner.
- Keep shared, truly cross-domain logic in `backend/app/core/` only when module ownership is not appropriate.
