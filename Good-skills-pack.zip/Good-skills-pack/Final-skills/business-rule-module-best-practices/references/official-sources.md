# Official Sources

Date reviewed: 25/02/2026

## Domain Modeling And Business Rules

- https://martinfowler.com/eaaCatalog/domainModel.html
- https://martinfowler.com/bliki/AnemicDomainModel.html
- https://learn.microsoft.com/en-us/dotnet/architecture/microservices/microservice-ddd-cqrs-patterns/domain-model-layer-validations

## FastAPI

- https://fastapi.tiangolo.com/tutorial/bigger-applications/
- https://fastapi.tiangolo.com/tutorial/dependencies/
- https://fastapi.tiangolo.com/tutorial/handling-errors/
- https://fastapi.tiangolo.com/tutorial/testing/

## Pydantic

- https://docs.pydantic.dev/latest/concepts/models/
- https://docs.pydantic.dev/latest/concepts/validators/

## SQLAlchemy

- https://docs.sqlalchemy.org/en/20/orm/session_basics.html
- https://docs.sqlalchemy.org/en/20/orm/queryguide/select.html

## PostgreSQL

- https://www.postgresql.org/docs/current/ddl-constraints.html
- https://www.postgresql.org/docs/current/indexes-partial.html
- https://www.postgresql.org/docs/current/transaction-iso.html
- https://www.postgresql.org/docs/current/explicit-locking.html

## API Error Contract Standards

- https://www.rfc-editor.org/rfc/rfc9457
