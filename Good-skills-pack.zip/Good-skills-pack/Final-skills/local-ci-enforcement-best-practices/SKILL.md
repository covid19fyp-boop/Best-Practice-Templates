---
name: local-ci-enforcement-best-practices
description: Enforce CI-quality gates in Git-only repositories and self-hosted runners using Docker-first workflows. Use when designing pre-commit or pre-push hooks, runner-agnostic validation jobs, stop-the-line checks, and reproducible local pipeline scripts for OpenAPI, migrations, tests, linting, and security scans.
---

# Local CI Enforcement Best Practices

Use this skill when a repository has no hosted CI but still needs enforceable quality gates.

## Instructions

1. Define one canonical validation entrypoint:
   - `infra/scripts/ci/validate-all.ps1`
2. Keep all gates Docker-first:
   - run lint, type checks, tests, migrations, and scans via `docker compose run`
3. Add local enforcement layers:
   - pre-commit for fast checks
   - pre-push for full stop-the-line checks
4. Keep a deterministic gate order:
   - evidence gate -> quality gate -> contract gate -> migration gate -> security gate
5. Enforce API contract checks:
   - export OpenAPI artifact
   - run breaking-change diff check
6. Enforce migration safety:
   - apply migrations on a fresh Postgres instance
   - fail if migration chain is invalid or incomplete
7. Enforce minimum testing pyramid gates:
   - required unit/integration checks
   - minimal smoke E2E if configured
8. Make runner portability explicit:
   - keep CI job definitions platform-agnostic
   - invoke the same scripts used by local hooks
9. Keep pass/fail criteria binary:
   - non-zero exit on any required gate failure

Use with:

- `skills/ci-cd-best-practices/SKILL.md`
- `skills/governance-evidence-gate-best-practices/SKILL.md`
- `skills/api-contract-versioning-best-practices/SKILL.md`
- `skills/alembic-migration-best-practices/SKILL.md`

Read:

- `references/ci-hooks-and-gates.md`
- `references/official-sources.md`

## Decision Criteria

- Prefer one shared validation script over duplicated runner logic.
- Block pushes on stop-the-line failures, not just warnings.
- Keep local hooks fast enough for daily use and full gates on push.
- Treat schema and contract checks as release-critical, even in personal projects.

## Examples

### Example 1: Git-only quality gate bootstrap

```text
Create pre-push validation for a local Git-only repo:
run evidence validation, OpenAPI diff, migration apply on fresh DB, tests, and security scans in Docker.
```

### Example 2: Runner-agnostic CI template

```text
Design a CI job template for Jenkins/GitLab/Drone that calls the same validate-all script used locally.
Avoid platform-specific duplicated gate logic.
```

### Example 3: Contract + migration hard fail policy

```text
Enforce a stop-the-line policy:
if OpenAPI breaking diff exists without approved version bump, or migration chain fails on fresh DB, block push.
```

## Anti-Patterns

- Maintaining separate local and CI validation logic.
- Running gates on host tools instead of Dockerized environments.
- Making security scans informational only for required paths.
- Treating API and migration checks as optional in pre-push gates.

## Checklist

- [ ] Canonical validate-all script exists and is documented.
- [ ] Pre-commit and pre-push hooks invoke Dockerized checks.
- [ ] OpenAPI export and breaking diff checks are automated.
- [ ] Migration apply check runs on fresh Postgres.
- [ ] Required unit/integration tests are part of stop-the-line gates.
- [ ] Security scans are included in enforcement workflow.
