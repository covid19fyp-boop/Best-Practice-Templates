# CI Hooks And Gates (Git-Only + Runner-Agnostic)

## Goal

Use the same deterministic validation flow locally and in any CI runner:

- local `git` hooks call script entrypoints
- external CI runners call the same script entrypoints

## Canonical Script Set

Recommended structure under `infra/scripts/ci/`:

- `validate-task-note.ps1`
- `lint-and-typecheck.ps1`
- `export-openapi.ps1`
- `check-openapi-breaking.ps1`
- `check-migrations.ps1`
- `run-tests.ps1`
- `security-scan.ps1`
- `validate-all.ps1`

`validate-all.ps1` should orchestrate all required gates in fixed order and fail on first critical error.

## Hook Strategy

- Pre-commit:
  - fast checks only (format/lint/static checks where feasible)
- Pre-push:
  - required stop-the-line gates, including contract, migrations, tests, and security scans

Use repository-managed hooks (for example `.githooks/`) and set:

```powershell
git config core.hooksPath .githooks
```

## Docker-First Command Pattern

Prefer commands that run tools in project containers:

```powershell
docker compose run --rm api sh -lc "<backend-check-command>"
docker compose run --rm frontend sh -lc "<frontend-check-command>"
docker compose run --rm api sh -lc "<openapi-export-or-diff-command>"
docker compose run --rm api sh -lc "<migration-safety-command>"
```

Keep command wrappers in scripts so hook files stay small and stable.

## Stop-The-Line Gate Baseline

Required gates for feature or schema changes:

1. Task evidence validation
2. Backend lint/type/unit/integration checks
3. Frontend lint/type/unit checks
4. OpenAPI export + breaking-change check
5. Migration apply check on fresh Postgres
6. Security scans (secrets, dependencies, container image when applicable)

## Optional But Recommended Gates

- Minimal critical-path E2E smoke checks
- Performance regression smoke checks for high-risk endpoints

## Runner Portability Rules

- Do not duplicate gate logic in each CI platform config.
- CI config should mostly call `infra/scripts/ci/validate-all.ps1`.
- Keep platform files thin wrappers that set env vars and collect artifacts.
