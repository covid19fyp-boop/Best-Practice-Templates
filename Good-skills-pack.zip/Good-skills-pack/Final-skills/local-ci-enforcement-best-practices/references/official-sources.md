# Official Sources

Date reviewed: 21/02/2026

## Git Hooks And Local Automation

- https://git-scm.com/docs/githooks
- https://pre-commit.com/

## Docker-First Execution

- https://docs.docker.com/compose/
- https://docs.docker.com/reference/cli/docker/compose/run/

## API Contract And Diff Governance

- https://fastapi.tiangolo.com/how-to/extending-openapi/
- https://spec.openapis.org/oas/latest.html
- https://github.com/OpenAPITools/openapi-diff

## Migration Safety

- https://alembic.sqlalchemy.org/en/latest/tutorial.html
- https://alembic.sqlalchemy.org/en/latest/autogenerate.html

## Security And Dependency Scanning

- https://github.com/gitleaks/gitleaks
- https://docs.npmjs.com/cli/v10/commands/npm-audit
- https://github.com/pypa/pip-audit
- https://trivy.dev/latest/docs/

## Runner-Agnostic CI References

- https://docs.gitlab.com/ee/ci/
- https://www.jenkins.io/doc/book/pipeline/
- https://drone.io/
