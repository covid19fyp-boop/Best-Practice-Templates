# Principles and Skill Routing

## Canonical Sources

- `AGENTS.md` is the primary policy source.
- `project_structure.md` is the primary structure and module contract source.

If this file and `AGENTS.md` differ, follow `AGENTS.md`.

## Core Principles

- Docker-first execution for install/build/test/lint/migrations.
- Modular monolith boundaries with explicit module ownership.
- Single-source-of-truth business rules; avoid duplicated logic.
- Contract-first API design with explicit DTOs.
- Migration safety with rollback awareness.
- Security and secrets hygiene by default.
- Test portfolio balance: unit + integration + minimal critical E2E.
- Small reversible changes with documented risks and release gates.

## Mandatory Baseline Skill Order

1. `repo-governance-skill-router`
2. `sdlc-personal-dev`
3. `architecture-modular-monolith`
4. `repo-structure-and-conventions`
5. `testing-strategy`
6. `technical-debt-controls`
7. `database-and-migrations`
8. `security-and-secrets`
9. `release-and-versioning`
10. `codex-cli-integration`

## Scenario Routing

### Cross-stack work

- `fullstack-fastapi-nextjs-postgres-docker`

### Finance module implementation and evolution

- `fastapi-best-practices`
- `alembic-migration-best-practices`
- `api-contract-versioning-best-practices`
- `module-consistency-best-practices`

### Security and access

- `security-best-practices`
- `auth-best-practices`

### Reliability and incident readiness

- `observability-best-practices`
- `error-solution-best-practices`
- `backup-restore-best-practices`

### Delivery and operations

- `ci-cd-best-practices`
- `local-ci-enforcement-best-practices`
- `governance-evidence-gate-best-practices`
- `feature-flag-release-best-practices`
- `maintenance-current-stack-best-practices`

### Performance and scalability validation

- `performance-load-testing-best-practices`
- `background-jobs-best-practices` (when async processing is introduced)

### Frontend and product UX

- `nextjs-best-practices`
- `modern-ui-ux-best-practices`
- `pwa-best-practices` (when PWA features are in scope)

### Locale, platform, and Codex operations

- `malaysia-format-english-fullstack`
- `git-windows-best-practices`
- `sdlc-codex-cli-best-practices`
- `codex-cli-hook-best-practices`
- `codex-cli-windows11-vscode-best-practices`
- `codex-rfc-codebase-research`
- `codex-research-best-practices`

### Skill governance

- `skill-best-practices`

## Pre-Implementation Output Contract

Before code edits, output:

1. Selected skill set (baseline + scenario-specific).
2. Architecture and module ownership constraints.
3. Migration and rollback concerns.
4. Testing scope and required gates.
5. Security and secrets review points.

Record this contract in a task evidence note under `docs/tasks/` so local hooks and CI can validate it.
