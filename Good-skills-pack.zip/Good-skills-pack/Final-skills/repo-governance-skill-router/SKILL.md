---
name: repo-governance-skill-router
description: Load repository governance, industry best practices, principles, business rules, and mandatory skill routing before starting any task in this repo. Use at the beginning of every request to choose required skills, enforce quality gates, and prevent policy drift or duplicated logic.
---

# Repo Governance Skill Router

Use this skill first in this repository before planning, coding, refactoring, or release work.

## Instructions

1. Run this skill as the first step of every task.
2. Read canonical governance files:
   - `AGENTS.md`
   - `project_structure.md`
3. Read this skill reference for routing and rules:
   - `references/principles-and-skill-routing.md`
4. Select baseline skills in required order.
5. Add scenario-specific skills based on task scope and risk.
6. Confirm architecture, migration, security, and testing gates before implementation.
7. Record selected skills and governing constraints in the task notes before editing code.
8. For code, infra, schema, or release work, add evidence and enforcement skills:
   - `governance-evidence-gate-best-practices`
   - `local-ci-enforcement-best-practices`

## Decision Criteria

- If a task touches two or more stack layers, include `fullstack-fastapi-nextjs-postgres-docker`.
- If a task is high-risk (security, migration, release, recovery), apply stricter skills and gates.
- If a rule conflicts with speed, follow the stricter governance rule.
- If similar logic already exists, reuse or refactor instead of duplicating.

## Examples

### Example 1: Start finance feature task

```text
Use $repo-governance-skill-router.
List baseline skills in required order, then add finance-specific skills.
Return: selected skills, architecture constraints, migration/test/security gates.
```

### Example 2: Plan cross-stack change

```text
Use $repo-governance-skill-router.
Task spans backend + frontend + database.
Return exact skill stack, rollout risks, and definition-of-done checklist.
```

### Example 3: Review PR for governance drift

```text
Use $repo-governance-skill-router.
Audit this PR for boundary violations, duplicated logic, missing tests, and migration risk.
Return findings by severity.
```

## Anti-Patterns

- Starting implementation before reading governance and routing rules.
- Using ad-hoc skill selection without baseline sequence.
- Duplicating business logic instead of reusing owner modules.
- Skipping migration, security, or testing gates due to urgency.

## Checklist

- [ ] Governance files were read before planning or coding.
- [ ] Baseline skills were selected in required order.
- [ ] Scenario-specific skills were added based on scope/risk.
- [ ] Reuse/duplication checks were completed.
- [ ] Quality gates are defined before implementation starts.
