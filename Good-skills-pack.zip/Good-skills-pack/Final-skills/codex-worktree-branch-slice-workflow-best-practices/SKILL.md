---
name: codex-worktree-branch-slice-workflow-best-practices
description: Plan and operate repo-specific worktree and branch slices for this repository. Use when deciding between local checkout and worktree, creating finance or attachment slice branches, moving Codex threads between Local and Worktree, bootstrapping `.env` in new worktrees, or cleaning up stale branches and linked worktrees safely on Windows.
---

# Codex Worktree And Branch Slice Workflow Best Practices

Follow this workflow when branch and worktree strategy is the main question for this repository.

## 1) Decide Local Branch Or Worktree First

- Use a local branch when only one slice is active and you do not need side-by-side checkouts.
- Use a dedicated worktree when slices are parallel, risky, or need separate Codex threads.
- Avoid long-lived module branches and module worktrees; prefer one branch per slice.

Read `references/repo-worktree-branch-model.md`.

## 2) Name Slices Using Repository Rules

- Keep the current default integration checkout on `master` unless the repository intentionally renames it.
- Prefix user-created slice branches with `codex/`.
- Use `<type>-<scope>-<yyyy-mm-dd>` after the prefix.
- Keep one task note, one primary module scope, and one coherent commit stream per branch.

Read `references/repo-worktree-branch-model.md`.

## 3) Handle Codex App Worktrees Correctly

- Treat Codex-managed worktrees and manual Git worktrees as separate workflows.
- If Codex opens a worktree in detached `HEAD`, create a branch before durable implementation or commit.
- Use Codex App `Hand off` to move a thread between Local and Worktree instead of trying to check out the same branch in both places.
- Run Codex App review before commit and use staged hunks to keep the slice tight.

Read `references/codex-app-worktree-behavior.md`.

## 4) Bootstrap Repo-Local State Per Worktree

- Ensure each worktree has the required local-only files before running services, especially `.env`.
- Keep startup Docker-first and prefer repository scripts over ad hoc command sequences.
- Re-run hook installation when repository Git config is missing or newly cloned.
- Do not assume ignored files or local caches follow a new worktree automatically.

Read `references/repo-worktree-branch-model.md`.

## 5) Avoid `ren` Parallel-Run Pitfalls

- Do not run multiple full `docker compose up` stacks concurrently across worktrees unless you intentionally override published ports.
- Published host-port collisions currently exist on `3000`, `8000`, `9000`, and `9001`.
- Prefer targeted Dockerized checks for parallel slices when you do not need the full stack.
- Treat finance and attachment as separate slice owners, but expect conflicts in shared docs, router composition, and migrations.

Read `references/repo-worktree-branch-model.md`.

## 6) Use Safe Git Command Patterns

- Inspect state with `git status --short --branch` and `git worktree list --porcelain`.
- Create new branches with `git switch -c`.
- Create manual linked worktrees with `git worktree add ... -b ... master`.
- Clean up merged slices with `git worktree remove`, `git branch --merged master`, `git branch -d`, and `git worktree prune`.
- Use `git worktree repair` if a worktree path moves unexpectedly.

Read `references/git-command-patterns.md`.

## 7) Verify Before Handoff Or Merge

- Keep a task evidence note under `docs/tasks/`.
- Run targeted checks during iteration, then run the full repository gate before merge.
- Record branch name, worktree path, validations run, and unresolved risks in the handoff.
- Add upstream tracking only after a remote exists and the branch is intended to be published.

Read `references/official-sources.md`.

## Decision Criteria

- Choose a worktree when context isolation, parallelism, or separate Codex threads matter more than extra setup.
- Choose a local branch when serial development in one checkout is enough.
- Prefer handoff over duplicate branch checkout across local and worktree contexts.
- Delete branches and remove worktrees as soon as a slice is merged and no longer needed.

## Examples

### Example 1: Parallel finance and attachment slices

```text
Use $codex-worktree-branch-slice-workflow-best-practices.
Create a finance summary slice and an attachment audit slice in parallel.
Return branch names, worktree strategy, `.env` bootstrap notes, and Docker collision warnings.
```

### Example 2: Convert a Codex-managed detached worktree into a durable slice

```text
Use $codex-worktree-branch-slice-workflow-best-practices.
This Codex worktree is in detached HEAD and I want to keep the work.
Return the safest branch-creation and handoff flow for this repo.
```

### Example 3: Clean up merged slice branches and stale worktrees

```text
Use $codex-worktree-branch-slice-workflow-best-practices.
Audit merged branches and stale worktrees in this repo on Windows and return safe cleanup commands only.
```

## Anti-Patterns

- Creating long-lived branches such as `codex/finance` or `codex/attachment` that accumulate unrelated slices.
- Running multiple full stacks from different worktrees with the same published ports.
- Assuming `.env` or other ignored files will exist in a new worktree automatically.
- Trying to check out the same branch in both Local and Worktree at once.
- Merging a slice without review, task evidence, and the Dockerized validation gate.

## Checklist

- [ ] Branch vs worktree choice matches the slice risk and parallelism needs.
- [ ] Branch name uses the `codex/` prefix and slice-based naming.
- [ ] Each worktree has required local-only bootstrap state, especially `.env`.
- [ ] Docker port-collision risk is checked before running full stacks.
- [ ] Review, task note, and validation gates are completed before merge or handoff.
