# Repo Worktree And Branch Model

This file maps generic Git and Codex worktree behavior onto `ren`.

## Integration Checkout

- Keep the repository root checkout on `master` as the clean integration checkout until the repository explicitly changes its default branch.
- Avoid doing non-trivial slice work directly on `master`.

## Slice Model

- Default rule: one branch per slice.
- Worktree rule: one worktree per parallel or high-risk slice.
- Do not keep one permanent branch per module unless the module truly has a long-lived independent stream.

## Branch Naming

- Prefix all user-created slice branches with `codex/`.
- Use this pattern:
- `codex/feature-finance-summary-2026-03-08`
- `codex/fix-attachment-restore-drill-2026-03-08`
- `codex/chore-docs-worktree-policy-2026-03-08`
- `codex/research-finance-reconciliation-2026-03-08`

## Worktree Naming

- For manual Git worktrees on Windows, keep them outside the repo root.
- Recommended root:
- `D:\Dev\Documents\GitHub\pj\ren-worktrees\`
- Recommended paths:
- `D:\Dev\Documents\GitHub\pj\ren-worktrees\finance-summary-2026-03-08`
- `D:\Dev\Documents\GitHub\pj\ren-worktrees\attachment-audit-2026-03-08`

## Choose Local Branch Vs Worktree

- Use only a branch in the main checkout when:
- one slice is active
- no side-by-side checkout is needed
- no separate Codex thread needs its own filesystem state

- Use a worktree when:
- finance and attachment work run in parallel
- a risky refactor should stay isolated
- you want a separate Codex thread with its own checkout
- you need to preserve unfinished work while starting another slice

## Local Bootstrap Per Worktree

- Each worktree needs its own `.env` because `.env` is ignored by Git.
- Use a local secure source to copy `.env`; do not commit secrets or rely on worktree creation to provide it.
- Git hook configuration is shared through repository config, but running `powershell -ExecutionPolicy Bypass -File infra/scripts/ci/install-hooks.ps1` is safe if hook state is unclear.
- Use `powershell -ExecutionPolicy Bypass -File infra/scripts/setup-worktree-env.ps1 -Profile <master|finance|dev>` to stamp a constant Compose project name and host-port profile into the current checkout `.env`.

## Canonical Runtime Profiles

- `master`: `COMPOSE_PROJECT_NAME=ren`, frontend `3000`, api `8000`, MinIO API `9000`, MinIO console `9001`
- `finance`: `COMPOSE_PROJECT_NAME=ren-finance`, frontend `3100`, api `8100`, MinIO API `9100`, MinIO console `9101`
- `dev`: `COMPOSE_PROJECT_NAME=ren-dev`, frontend `3200`, api `8200`, MinIO API `9200`, MinIO console `9201`
- PostgreSQL stays internal to Compose and does not publish a host port by default.

## When You Are Not In `master`

- Check the current context first:
- `git status --short --branch`
- If the branch is not `master`, treat the worktree as an isolated slice workspace.
- Keep changes limited to the intended slice and module ownership for that worktree.
- Do not assume `master` has your changes until you explicitly merge or fast-forward them back.
- If `master` advanced while you were working, bring those changes into the worktree with an explicit merge or rebase.
- Before running a full local stack from the worktree, confirm another worktree is not already using published ports.
- Prefer the canonical runtime profile map over ad hoc port overrides so worktree URLs stay predictable.
- Before integration, run review, update the task note, and complete the repository validation gate.

## Docker And Runtime Constraints

- `docker-compose.yml` publishes these host ports:
- frontend: `3000`
- api: `8000`
- minio: `9000`
- minio console: `9001`
- Do not run two full `docker compose up` stacks concurrently across worktrees without overriding ports.
- Targeted `docker compose run --rm ...` checks are usually safer for parallel slice validation because they do not depend on published host ports in the same way as `up`.
- Compose project names will differ by checkout directory name, so volumes and container names are usually isolated by path, but host-port bindings still collide.

## Remote And Upstream Rules

- This repository currently has no Git remote configured.
- Create local branches without upstream by default.
- Add tracking or push policy only after a remote is intentionally added.

## Recommended Creation Method

- For this repository, prefer manual `git worktree add` when you want long-lived finance and dev worktrees:
- path stays under your control on Windows
- easier to keep a stable folder layout such as `D:\Dev\Documents\GitHub\pj\ren-worktrees\...`
- easier to reopen in external tools without relying on Codex-managed storage
- after creation, run `infra/scripts/setup-worktree-env.ps1` immediately so the worktree gets its fixed local port profile before any stack startup

- Prefer Codex App permanent worktrees when:
- the worktree should stay tightly associated with a Codex thread
- Codex App `Hand off` and app-managed worktree retention matter more than path control
- you are okay with Codex managing the worktree location under `$CODEX_HOME/worktrees`

## Merge And Cleanup Discipline

- Review and validate before merge.
- Merge the slice back to `master`.
- Remove the linked worktree after merge.
- Delete the merged branch with safe delete commands, not force delete by default.
