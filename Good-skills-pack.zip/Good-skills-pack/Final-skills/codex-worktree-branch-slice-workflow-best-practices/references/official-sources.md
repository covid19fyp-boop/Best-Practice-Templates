# Official Sources

Date reviewed: 08/03/2026

## OpenAI Codex App Docs

- https://developers.openai.com/codex/app/worktrees
- https://developers.openai.com/codex/app/review
- https://developers.openai.com/codex/app/local-environments
- https://developers.openai.com/codex/app/windows

## Git Docs

- https://git-scm.com/docs/git-worktree
- https://git-scm.com/docs/git-branch
- https://git-scm.com/docs/git-switch
