# Codex App Worktree Behavior

Use this reference for Codex App-specific behavior that affects this repository.

## Core Rules

- Codex App worktrees are intended for parallel work on the same repository.
- Codex-managed worktrees can begin in detached `HEAD`.
- When work becomes durable, create a branch in the worktree before commit or long-lived handoff.
- If you want to continue the same slice in your local checkout, use `Hand off` instead of trying to check out the same branch in both places.

## Local State Implications

- Worktrees run in separate directories from the main checkout.
- Local environments exist so setup scripts can recreate missing local-only state for new worktrees.
- This matters for `ren` because `.env` is ignored and is required by several Docker services.

## Review Behavior

- Codex App review supports inline comments and scoped Git operations.
- Stage, unstage, and revert can be done for the full diff, a file, or a single hunk.
- Use review before commit so slice boundaries stay tight and findings stay attached to the right branch/worktree.

## Lifecycle And Cleanup

- Codex-managed worktrees are kept under `$CODEX_HOME/worktrees`.
- Codex automatically manages disk usage for Codex-managed worktrees and can restore deleted-worktree snapshots for associated threads.
- Permanent, pinned, and still-in-progress worktrees are preserved from automatic cleanup.

## Repository Implication

- Use Codex-managed worktrees when the thread should stay tightly coupled to Codex App.
- Use manual Git worktrees when you want a path you control, such as `D:\Dev\Documents\GitHub\pj\ren-worktrees\...`.
