# Git Command Patterns

Use these commands as safe starting points for this repository on Windows.

## Inspect State

```powershell
git status --short --branch
git worktree list --porcelain
git branch --all
```

## Create A Slice Branch In The Current Checkout

```powershell
git switch -c codex/chore-docs-worktree-policy-2026-03-08
```

## Create A Manual Linked Worktree From `master`

```powershell
git worktree add ..\ren-worktrees\finance-summary-2026-03-08 -b codex/feature-finance-summary-2026-03-08 master
```

## Convert Detached `HEAD` Work Into A Durable Branch

```powershell
git switch -c codex/feature-finance-summary-2026-03-08
```

## Remove A Merged Worktree And Branch

```powershell
git worktree remove ..\ren-worktrees\finance-summary-2026-03-08
git branch --merged master
git branch -d codex/feature-finance-summary-2026-03-08
```

## Audit Stale Worktree Metadata

```powershell
git worktree prune --dry-run
git worktree prune
```

## Repair A Moved Worktree

```powershell
git worktree repair
```

## Optional Lock For A Long-Lived Manual Worktree

```powershell
git worktree lock ..\ren-worktrees\finance-summary-2026-03-08 --reason "long-lived finance slice"
```
