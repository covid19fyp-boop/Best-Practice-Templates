# Automation Catalog For `ren`

Use this catalog as the default starting set.

| Automation name | Cadence | Goal | Primary command path | Output |
| --- | --- | --- | --- | --- |
| Local CI full gate | Nightly | Detect regressions early | `infra/scripts/ci/validate-all.ps1` | Pass/fail report with failing stage and next action |
| Finance write-path health | Daily | Catch finance reliability drift | finance tests + write-path drill script | Alert when retries/conflicts/alerts deviate |
| OpenAPI drift watch | Daily | Detect contract changes needing explicit review | OpenAPI export + diff checks | Contract drift summary with compatibility risk |
| Dependency and vuln hygiene | Weekly | Surface dependency security drift | dependency audit and scan steps in local CI | Remediation list with severity |
| Docs and governance drift | Weekly | Keep governance docs aligned | task note checks + docs consistency checks | Missing/invalid docs evidence report |

## Recommended Rollout Order

1. Start with read-only reporting automations.
2. Add branch-producing automations after reports are stable.
3. Add write-capable automation only with strict review gates.

## Incident Handling

- If two consecutive runs fail for the same reason, open a dedicated fix slice.
- If failure affects release-critical gates, pause write-capable automations until fixed.
