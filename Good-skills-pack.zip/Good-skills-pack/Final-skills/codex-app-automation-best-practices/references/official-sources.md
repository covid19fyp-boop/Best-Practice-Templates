# Official Sources

Date reviewed: 05/03/2026

## OpenAI Codex App Docs

- https://developers.openai.com/codex/app/features
- https://developers.openai.com/codex/app/automations
- https://developers.openai.com/codex/app/worktrees
- https://developers.openai.com/codex/app/review
- https://developers.openai.com/codex/app/settings

## OpenAI Help And Announcement

- https://help.openai.com/en/articles/11369540-codex-in-chatgpt
- https://openai.com/index/introducing-the-codex-app/
