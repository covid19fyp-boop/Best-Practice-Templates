# Automation Guardrails

## Scope Control

- One automation, one purpose.
- Keep prompts explicit about allowed paths.
- Require branch isolation for any write output.

## Command Safety

- Use Docker-first commands only.
- Avoid destructive commands unless explicitly approved.
- Prefer non-interactive commands for deterministic execution.

## Quality Gates

- Treat `infra/scripts/ci/validate-all.ps1` as stop-the-line for merge readiness.
- Require task evidence note updates for automation-generated changes.
- Require review before commit or merge.

## Security

- Do not place secrets in automation prompts.
- Keep approval and sandbox settings least-privilege by default.
- Document any escalation reason in task evidence.

## Recovery

- Ensure failed automation output is reproducible locally.
- Keep rollback posture simple: revert automation-produced commits when needed.
