---
name: codex-app-automation-best-practices
description: Design and run Codex App automations safely for this repository. Use when creating scheduled or event-based Codex App automations, defining automation prompts and guardrails, wiring Docker-first validation flows, triaging automation output, or converting automation findings into scoped implementation slices.
---

# Codex App Automation Best Practices

Follow this workflow when using Codex App Automations for this repository.

## 1) Define Automation Intent Before Scheduling

- Choose one clear objective per automation.
- Define pass/fail output and escalation path.
- Keep automation scope narrow and reproducible.

Read `references/automation-catalog-for-ren.md`.

## 2) Use Docker-First Repository Commands

- Use repository scripts and Dockerized commands only.
- Avoid host dependency assumptions.
- Keep automation command flow deterministic.

Read `references/automation-guardrails.md`.

## 3) Set Safe Write Boundaries

- Prefer read-only automations for reporting and drift detection.
- For write-capable automations, require explicit branch + review + commit policy.
- Never combine broad code generation with auto-merge.

Read `references/automation-guardrails.md`.

## 4) Integrate With Worktree And Review Flow

- Route automation implementation output into dedicated branches/worktrees.
- Run review before accepting automated code proposals.
- Track unresolved risks in task notes.

Read `references/automation-guardrails.md`.

## 5) Handle Failures With Runbook Discipline

- Capture failure command, timestamp, and probable cause.
- Retry only after root-cause hypothesis is explicit.
- Promote recurring failures into infra/docs fixes.

Read `references/automation-catalog-for-ren.md`.

## 6) Verify Before Handoff

- Re-run critical checks locally before commit:
  - `powershell -ExecutionPolicy Bypass -File infra/scripts/ci/validate-all.ps1`
- Ensure task evidence note reflects automation-produced changes.

For canonical updates, read `references/official-sources.md`.

## Decision Criteria

- Prefer fewer high-signal automations over many noisy jobs.
- Prefer weekly or nightly cadence for expensive checks.
- Prefer non-destructive automations unless explicit write scope is approved.
- Stop and escalate when automation outputs conflict with governance rules.

## Examples

### Example 1: Nightly CI validation automation

```text
Use $codex-app-automation-best-practices.
Create a nightly automation that runs repository validation and reports failures with concrete next actions.
```

### Example 2: Weekly dependency and security drift automation

```text
Use $codex-app-automation-best-practices.
Design an automation to check dependency/security drift and open a scoped remediation branch.
```

### Example 3: Finance module health regression watch

```text
Use $codex-app-automation-best-practices.
Schedule a finance-focused regression automation that validates API contracts, migrations, and write-path safety checks.
```

## Anti-Patterns

- Running broad write-capable automation with no branch isolation.
- Using host tools that bypass Docker-first governance.
- Auto-accepting automation-generated commits without review.
- Ignoring repeated automation failures instead of fixing root causes.

## Checklist

- [ ] Automation objective and success criteria are explicit.
- [ ] Commands are Docker-first and repository-owned.
- [ ] Write scope and branch policy are controlled.
- [ ] Review/handoff path is defined.
- [ ] Failure handling and follow-up ownership are documented.
