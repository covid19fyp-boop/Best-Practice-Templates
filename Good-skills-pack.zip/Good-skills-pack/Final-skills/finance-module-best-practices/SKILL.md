---
name: finance-module-best-practices
description: Design and evolve finance-domain modules for this FastAPI and PostgreSQL modular monolith with correctness and operational safety controls. Use when creating or refactoring finance transactions or ledger flows, money and currency models, idempotent create endpoints, concurrency-sensitive posting logic, reconciliation or correction workflows, finance migrations, or finance-focused tests and rollout gates.
---

# Finance Module Best Practices

Follow this workflow when implementing or reviewing finance-domain capabilities.

## 1) Lock Finance Capability Boundaries

- Keep finance write ownership in `backend/app/modules/finance/`.
- Define explicit non-responsibilities for `core`, `dev`, and other modules.
- Keep cross-module access through finance service or API contracts only.

Read `references/domain-boundaries-and-correction-model.md`.

## 2) Model Money And Currency Safely

- Store persisted monetary amounts as integer minor units when fixed-scale currency is enough.
- If fractional precision beyond minor units is required, use exact decimal types (`NUMERIC` in PostgreSQL and `Decimal` in Python) with explicit rounding rules.
- Do not use binary floating-point for persisted financial amounts.

Read `references/money-idempotency-and-integrity.md`.

## 3) Enforce Idempotent Create Paths

- Require an idempotency key for finance create operations that can be retried.
- Persist idempotency keys with a database uniqueness guarantee.
- Return retry-safe outcomes when key semantics and request payload semantics match.

Read `references/money-idempotency-and-integrity.md`.

## 4) Design For Transactional Integrity And Concurrency

- Back hard invariants with `CHECK`, `UNIQUE`, and foreign key constraints.
- Keep transaction boundaries explicit for posting and correction flows.
- Use row-level locking (`FOR UPDATE`) where concurrent writes can violate invariants.

Read `references/money-idempotency-and-integrity.md`.

## 5) Keep Correction And Audit Behavior Explicit

- Prefer append-only correction flows (reversal or adjustment entries) for posted transactions.
- Avoid destructive edits of posted financial records unless there is a documented emergency procedure.
- Capture actor, timestamp, source action id, and correlation id for finance mutations.

Read `references/domain-boundaries-and-correction-model.md`.
Read `references/security-logging-and-recovery.md`.

## 6) Apply Finance-Sensitive Security And Logging Controls

- Evaluate endpoints against OWASP API Security Top 10 risk classes.
- Keep authorization checks explicit on all finance mutation paths.
- Exclude secrets, tokens, and high-risk personal data from logs.

Read `references/security-logging-and-recovery.md`.

## 7) Make Recovery Operational, Not Aspirational

- Define backup and restore objectives before releasing finance changes.
- Combine logical backups with point-in-time recovery strategy where recovery precision is required.
- Test restore procedures on a regular cadence and after major schema changes.

Read `references/security-logging-and-recovery.md`.

## 8) Verify With Finance-Focused Gates

- Unit-test finance invariants and rounding or idempotency rules.
- Integration-test retries, unique key conflicts, lock or concurrency behavior, and migration safety.
- Run repository Docker-first CI gates before merge.

For canonical sources and update checks, read `references/official-sources.md`.
