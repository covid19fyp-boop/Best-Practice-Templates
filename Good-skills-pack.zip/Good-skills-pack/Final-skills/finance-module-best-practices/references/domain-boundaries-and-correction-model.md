# Domain Boundaries and Correction Model

Date reviewed: 27/02/2026

## Finance Module Ownership

- Keep finance write paths inside `backend/app/modules/finance`.
- Treat `finance` as the owner for transaction data model and migration lifecycle.
- Keep `api -> service -> domain/repo` dependency flow as the module baseline.

## Cross-Module Consumption

- Other modules consume finance behavior through explicit service or API contracts.
- Do not allow direct cross-module table writes into finance-owned tables.

## Correction Posture

- Prefer append-only corrections (for example reversal and replacement entries) for posted records.
- Keep destructive edits and deletes as exception-only operations with explicit runbook steps.
- Keep audit metadata with each mutation request path (`actor`, `source`, `timestamp`, `correlation id`).

## Why This Matters

- Finance correctness is safer when write ownership is centralized.
- Explicit correction records support traceability and simpler rollback posture than in-place mutation.
