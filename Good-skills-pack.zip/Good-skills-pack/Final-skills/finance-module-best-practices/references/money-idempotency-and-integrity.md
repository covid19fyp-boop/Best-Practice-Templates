# Money, Idempotency, and Integrity Notes

Date reviewed: 27/02/2026

## Money Representation

- PostgreSQL documents that `numeric` can store numbers with a very large number of digits and exact precision, while arithmetic on `numeric` is very slow compared to integer and floating-point types.
- PostgreSQL documents that `money` output is locale-sensitive and warns that data transfer for `money` can fail if locale is not aligned.
- Python `decimal` exists to avoid binary floating-point representation issues and supports exact decimal arithmetic with configurable precision and rounding.
- Stripe documents API amounts in the smallest currency unit and provides a currency list including zero-decimal currencies.

Practical implication:
- Prefer integer minor units for common transaction amounts.
- Use exact decimal types with explicit rounding policy only when variable precision is required.

## Idempotency For Retry-Safe Creates

- Stripe documents that idempotency keys are client-generated, can be reused for safe retries, and that the first response is replayed for subsequent requests with the same key.
- Stripe documents key retention guidance and payload-parameter checks for mismatch protection.

Practical implication:
- Persist idempotency keys in finance write paths with unique constraints and defined replay semantics.

## Transactional Integrity and Concurrency

- PostgreSQL defines transaction isolation levels and anomaly behavior by level.
- PostgreSQL provides row-level locking (`FOR UPDATE`) for race-sensitive updates.
- PostgreSQL constraint documentation defines `CHECK` and `UNIQUE` constraints for data integrity guarantees.

Practical implication:
- Use database constraints plus explicit locking and transaction boundaries as the final integrity layer for finance writes.
