# Security, Logging, and Recovery Notes

Date reviewed: 27/02/2026

## API Security Baseline

- OWASP API Security Top 10 (2023) identifies common API risk classes such as broken object-level authorization, authentication failures, and excessive data exposure.

Practical implication:
- Evaluate every finance endpoint against these risk classes and require explicit authorization for mutation paths.

## Logging Hygiene

- OWASP Logging Cheat Sheet documents categories of data that should usually be excluded or handled specially in logs, including session identifiers, access tokens, encryption keys, and sensitive personal data.

Practical implication:
- Keep finance logs useful for diagnostics and audits, but redact or avoid sensitive fields by default.

## Backup and Restore

- PostgreSQL `pg_dump` documentation states dumps are internally consistent and do not block other users.
- PostgreSQL continuous archiving and point-in-time recovery documentation states WAL archiving enables recovery to a specific time when paired with base backups.

Practical implication:
- Use both logical backup and point-in-time recovery planning for finance data, then test restore drills.
