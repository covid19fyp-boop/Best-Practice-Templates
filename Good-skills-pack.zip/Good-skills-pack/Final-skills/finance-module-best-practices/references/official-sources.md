# Official Sources

Date reviewed: 27/02/2026

## PostgreSQL

- https://www.postgresql.org/docs/current/datatype-numeric.html
- https://www.postgresql.org/docs/current/datatype-money.html
- https://www.postgresql.org/docs/current/transaction-iso.html
- https://www.postgresql.org/docs/current/sql-select.html
- https://www.postgresql.org/docs/current/explicit-locking.html
- https://www.postgresql.org/docs/current/ddl-constraints.html
- https://www.postgresql.org/docs/current/app-pgdump.html
- https://www.postgresql.org/docs/current/continuous-archiving.html

## Python

- https://docs.python.org/3/library/decimal.html

## Stripe

- https://docs.stripe.com/api/idempotent_requests
- https://docs.stripe.com/currencies

## OWASP

- https://owasp.org/API-Security/editions/2023/en/0x11-t10/
- https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html
