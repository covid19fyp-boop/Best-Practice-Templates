---
name: finance-frontend-ui-ux-best-practices
description: Design and review modern finance module frontend experiences in Next.js with trustworthy money presentation, transaction entry flows, transaction tables, summary dashboards, correction and reversal UX, and finance ops or reconciliation surfaces. Use when planning or implementing finance-specific UI or UX for this repository.
---

# Finance Frontend UI/UX Best Practices

Follow this workflow when planning, implementing, or reviewing finance-module frontend UX.

## 1) Start From Finance User Jobs

- Identify the primary journeys first: summary review, transaction capture, ledger scanning, transaction detail review, reversal or correction, and ops visibility.
- Keep money-moving actions distinct from read-only analytics or monitoring surfaces.
- Map every planned screen to existing finance API contracts instead of inventing frontend-only business rules.

Read `references/user-journeys-and-screen-map.md`.

## 2) Make Money And Status Immediately Legible

- Format money explicitly from finance minor units; never let binary floating-point or ambiguous symbol-only formatting leak into the UI contract.
- Show currency code when ambiguity is possible, especially in multi-currency tables and selectors.
- Prefer tables for transaction history and comparison work; use cards for summaries and entry points, not as a replacement for a ledger.
- Keep status treatments consistent for source, reversal, warning, and error states.

Read `references/money-display-and-transaction-surfaces.md`.

## 3) Guard Important Mutations

- Treat create, reversal, and other financially meaningful actions as trust-critical UX, not ordinary forms.
- Provide validation, review, confirmation, or undo paths for important submissions.
- Keep error feedback both local (near the affected control) and global (summary or section-level callout) when mistakes block completion.
- Make correction lineage and audit metadata visible in detail views.

Read `references/corrections-confirmations-and-trust.md`.

## 4) Design Dense Data For Real Usage

- Give ledgers and ops tables enough horizontal room, clear captions, strong column labels, and predictable pagination.
- Keep global table actions in a toolbar and preserve filter state in the URL for shareability and return visits.
- Use empty states to explain what belongs on the screen and what the next productive action is.
- Keep dashboards summary-first and let users drill into tables or detail views for investigation.

Read `references/dense-data-responsive-and-empty-states.md`.

## 5) Keep Mobile And Accessibility First-Class

- Keep primary finance journeys full-screen on mobile; use overlays only for short, supplementary tasks.
- Ensure keyboard focus is obvious, strong, and high-contrast.
- Use short labels, concise helper copy, and semantic table structures.
- Keep Malaysia formatting explicit for dates and times unless product policy changes.

Read `references/accessibility-mobile-and-content.md`.

## 6) Fit The Repository Frontend Contract

- Keep feature styling in `*.module.css` files and shared primitives in the repo token and utility system.
- Respect Next.js App Router server/client boundaries and keep finance auth on server-side boundaries.
- Reuse repo conventions from `frontend/styles/`, `frontend/lib/`, and existing module workspaces instead of adding an ad hoc finance UI stack.
- Pair this skill with `nextjs-best-practices`, `modern-ui-ux-best-practices`, and `finance-module-best-practices` when implementation spans framework, generic UX, and domain correctness.

Read `references/repo-integration.md`.

## Decision Criteria

- Prefer tables when users need scanning, comparison, sorting, or historical review.
- Prefer summary cards for high-level metrics or distinct calls to action, not long lists of transactions.
- Prefer explicit confirmation or reversible submission patterns for financial mutations.
- Prefer system-generated idempotency and request-trace behavior behind the scenes rather than exposing raw backend mechanics to end users.

## Examples

### Example 1: Finance dashboard planning

```text
Use $finance-frontend-ui-ux-best-practices.
Plan a finance overview screen with summary cards, recent transactions, and ops alert callouts.
Return screen sections, loading or empty states, and responsive behavior.
```

### Example 2: Transaction ledger review

```text
Use $finance-frontend-ui-ux-best-practices.
Review this finance transaction table for readability, filtering, and correction-flow clarity.
Return UX findings and recommended fixes.
```

### Example 3: Reversal flow design

```text
Use $finance-frontend-ui-ux-best-practices.
Design a safe reversal confirmation flow for the finance module.
Include validation, confirmation, focus handling, and audit visibility requirements.
```

## Anti-Patterns

- Replacing a transaction ledger with a grid of cards that is hard to scan.
- Asking end users to manually provide backend-only finance fields such as idempotency keys.
- Hiding reversal lineage, audit context, or important warnings behind secondary navigation.
- Using bottom sheets or small modals for dense transaction tables or multi-step financial workflows.
- Encoding finance-specific styles in global CSS instead of module-local styles and shared tokens.

## Checklist

- [ ] Planned screens map to real finance contracts and user jobs.
- [ ] Money, currency, and status presentation are unambiguous.
- [ ] Financial mutations include validation and confirmation or reversal safety.
- [ ] Tables, filters, empty states, and mobile fallbacks are intentional.
- [ ] Accessibility, focus, and Malaysia formatting are explicit.
- [ ] Repo token, CSS Module, and Next.js boundary rules are respected.
