# Repo Integration

Date reviewed: 08/03/2026

## Frontend Structure Fit

- Put finance routes under `frontend/app/finance/`.
- Put finance API adapters and contracts under `frontend/lib/finance/`.
- Keep feature-specific styling in colocated `*.module.css` files.
- Use shared utility classes only for generic layout and state primitives.

## Visual Contract Fit

- Reuse the repo token contract from `frontend/styles/tokens/*.tokens.json`.
- Generate token output through the existing token pipeline instead of hardcoding values.
- Use semantic state tokens for success, warning, and danger.
- Keep any finance-specific class names out of global utilities.

## Interaction Fit

- Reuse existing page-shell, surface, badge, and callout patterns where they help comprehension.
- Prefer a denser ledger treatment than the current attachment workspace, because finance review work is more comparison-heavy.
- Keep ops cards compact and actionable, then route to detail views for deeper inspection.

## Next.js And Security Fit

- Keep finance data loading server-first unless direct client interactivity is required.
- Keep finance auth secrets and privileged mutation flows on the server.
- Use Route Handlers or Server Actions carefully for finance mutations, with explicit validation and authorization.
- Avoid pushing finance bearer tokens into public client bundles or ad hoc browser storage.

## Testing Fit

- Add frontend tests for formatting, filters, empty states, and focus-visible behavior where practical.
- Keep Dockerized lint, test, token, accessibility, and style-governance gates in the normal repo workflow.
