# Accessibility, Mobile, And Content

Date reviewed: 08/03/2026

## Focus And Keyboard Access

- Keep keyboard focus clearly visible with a strong indicator that is at least visually equivalent to a 2px perimeter.
- Ensure focus contrast is strong against adjacent colors.
- Do not remove or weaken focus styling in custom finance controls.

## Table Accessibility

- Use captions to help users identify what a table contains.
- For complex tables, provide a summary that explains the organization of rows and columns.
- Keep semantic headers intact so assistive technology can navigate the ledger correctly.

## Mobile Overlays

- Use bottom sheets only for short, supplementary tasks or supporting content on mobile.
- Do not place nested navigation or long finance workflows inside bottom sheets.
- Do not use bottom sheets for dense tables or primary finance flows that need sustained context.

## Input Labels And Helper Text

- Prefer short, noun-based labels.
- Use concise helper text when users need context; do not depend on placeholders for instructions.
- Keep component-level prompts close to the affected control and section-level prompts near the impacted group of controls.

## Locale And Copy

- Use English content.
- Use Malaysia date and time formatting for finance screens in this repository: `DD/MM/YYYY` and `24-hour`.
- Front-load important information in mobile supporting surfaces so the user can act quickly without reading excess copy.
