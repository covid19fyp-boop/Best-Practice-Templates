# Official Sources

Date reviewed: 08/03/2026

## W3C

- https://www.w3.org/WAI/tutorials/forms/notifications/
- https://www.w3.org/WAI/WCAG22/Understanding/error-prevention-legal-financial-data.html
- https://www.w3.org/WAI/WCAG22/Understanding/focus-appearance.html
- https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/
- https://www.w3.org/WAI/tutorials/tables/caption-summary/

## Carbon Design System

- https://carbondesignsystem.com/components/data-table/usage/
- https://carbondesignsystem.com/patterns/empty-states-pattern/

## Wise Design

- https://wise.design/components/money-input
- https://wise.design/components/expressive-money-input
- https://wise.design/components/table
- https://wise.design/components/bottom-sheet
- https://wise.design/components/card
- https://wise.design/components/inline-prompt
- https://wise.design/components/info-prompt
- https://wise.design/components/text-input
