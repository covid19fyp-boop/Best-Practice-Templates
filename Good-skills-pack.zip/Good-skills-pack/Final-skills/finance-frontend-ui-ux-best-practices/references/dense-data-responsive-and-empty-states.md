# Dense Data, Responsive Behavior, And Empty States

Date reviewed: 08/03/2026

## Table Layout

- Place data tables in the main content area and give them enough space to avoid unnecessary truncation.
- Keep pagination controls at the bottom of the table.
- Use a dedicated toolbar for global table actions such as search, filters, export, and settings.
- Keep row hover or active scan states enabled so users can follow data across columns.

## Search And Filters

- Keep search and global filters close to the table title or toolbar.
- Preserve active filters, date windows, and cursor state in the URL when practical so the user can refresh, share, or return to the same view.
- Distinguish global table filters from per-row actions.

## Dashboard Composition

- Start with a small number of high-signal summary cards.
- Use cards to answer “what changed?” and tables to answer “which records are responsible?”.
- Keep dashboards drillable; a metric card should lead to a filtered ledger or detail view, not a dead end.

## Empty States

- Explain what would normally appear on the screen.
- Tell the user what next action will populate or fix the state.
- Keep the primary action direct and obvious.
- Use plain, respectful language rather than jokes or filler.

## Responsive Behavior

- Let tables scroll horizontally on narrow screens instead of hiding critical finance data.
- Keep summaries and actions stacked cleanly on mobile.
- Reserve overlays for supplementary interactions and move dense or multi-step finance work into full-screen routes.
