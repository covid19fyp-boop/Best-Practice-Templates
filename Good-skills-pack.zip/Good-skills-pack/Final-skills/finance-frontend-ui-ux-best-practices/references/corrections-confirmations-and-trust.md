# Corrections, Confirmations, And Trust

Date reviewed: 08/03/2026

## Financial Error Prevention Baseline

- For financially meaningful actions, provide at least one of these safeguards: reversibility, input checking with correction opportunity, or a final review and confirmation step.
- Validate fields before submission and show users exactly what needs to be fixed.
- For non-trivial finance actions, show a compact review summary before final submission.

## Error Messaging

- Use both:
- local feedback near the affected control for field-level mistakes.
- a top-level error summary when submission fails or multiple errors exist.
- Error summaries should identify the problem clearly, explain the correction, and link back to the affected controls when possible.

## Dialog And Confirmation Patterns

- Modal dialogs must trap focus and return focus logically when closed.
- Focus should move inside the dialog when it opens.
- For destructive or difficult-to-reverse financial actions, initial focus should favor the least destructive action.
- Include an always-visible close or cancel action.

## Correction And Reversal UX

- Keep reversal flows append-only in the UI language as well as the data model; avoid wording that implies silent in-place edits of posted records.
- Show the original transaction summary, resulting reversal effect, reason code, and audit trace before confirmation.
- Make correction lineage visible from detail views so users can understand what happened and why.

## Trust Signals For This Repository

- Surface `created_by_module`, `action_request_id`, and correction metadata in detail or audit views rather than hiding them entirely.
- Treat request deduplication and idempotency as system reliability features, not manual user tasks.
- Keep ops and alert messages factual and plain; avoid celebratory or vague wording for finance warnings and errors.
