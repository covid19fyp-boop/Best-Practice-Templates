# Money Display And Transaction Surfaces

Date reviewed: 08/03/2026

## Money Entry

- Use a dedicated money input for amount entry instead of a generic text field.
- Keep the label and surrounding copy explicit about what amount the user is entering.
- In money inputs and currency selectors, show currency code plus currency name instead of symbol-only labels when ambiguity is possible.
- Reserve expressive or calculator-style money inputs for money movement experiences, not generic forms.

## Money Display

- Convert backend minor units into user-facing formatted amounts at the presentation layer only.
- When multiple currencies can appear together, show the currency code near the amount; do not rely on symbols like `$` alone.
- Keep positive and negative meaning consistent across typography, color, and status indicators. Color alone must never carry the meaning.

## Ledger And Table Surfaces

- Use a table for transaction history, reconciliation review, and record comparison work.
- Keep currency cells right-aligned to improve numeric scanning.
- Keep cell content short and scannable; move long narrative or audit detail into expandable detail areas or dedicated detail views.
- Give the ledger enough width and allow horizontal scrolling on narrow screens instead of collapsing critical columns into unreadable stacks.
- Do not place detailed transaction tables inside cramped modals or drawers.

## Cards And Summaries

- Use cards for top-level summaries, alerts, or entry points into deeper finance views.
- Do not turn a long transaction list into cards when a table would be more legible.
- Keep cards easy to scan with clear hierarchy and a single topical purpose.

## State Treatments

- Distinguish source transactions, reversal transactions, warnings, and error states with consistent status treatments.
- Keep success, warning, danger, and neutral meanings aligned with repo semantic tokens rather than ad hoc colors.
