# User Journeys And Screen Map

Date reviewed: 08/03/2026

## Primary Finance Jobs

- Check the current position quickly.
- Add a transaction with confidence.
- Review historical transactions and find a specific record.
- Inspect transaction details, audit context, and correction lineage.
- Reverse or correct a transaction safely.
- Monitor reconciliation or write-path health when operational signals matter.

## Recommended Screen Map For This Repository

### Finance Overview

- Summary cards for totals, credits, debits, and net balance.
- Short recent-activity preview that links to the full ledger.
- Optional ops callouts when reconciliation or write-path alerts are active.

### Finance Transactions

- Table-first ledger with filters for currency, transaction type, module, date window, and reversal inclusion.
- Cursor-aware pagination or continuation flow that preserves filter context in the URL.
- Strong status treatment for normal, reversal, warning, and error conditions.

### Finance Transaction Detail

- Transaction basics: description, amount, type, currency, created time.
- Audit and trace metadata: `created_by_module`, `action_request_id`.
- Correction context: `source_transaction_id`, `correction_reason_code`.
- Linked actions: copy reference, open source transaction, start reversal flow.

### Finance Mutation Flows

- Create transaction form with user-facing business fields only.
- Review or confirmation step for high-impact actions.
- Reversal confirmation that clearly shows source transaction details and resulting opposite transaction type.

### Finance Ops

- High-level cards for reconciliation counts and write-path alerts.
- Drill-down link from summary cards into filtered ledger or detail views.
- Prometheus or status text can remain developer-facing, but UI should translate them into plain-language health summaries.

## Repository-Specific Inference

- The finance API requires an idempotency key, but a human-facing frontend should generate and manage retry-safe request identifiers behind the scenes rather than asking the user to type one.
- The current finance module is API-first, so a future frontend should preserve backend ownership and not duplicate business rules such as reversal eligibility or cursor compatibility.
- Existing repo patterns from the attachment workspace are useful for page structure and callouts, but finance screens should be denser and more table-oriented.
