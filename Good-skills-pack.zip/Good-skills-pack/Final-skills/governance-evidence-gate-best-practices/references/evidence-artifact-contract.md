# Evidence Artifact Contract

## Canonical Location

- Store task evidence notes in `docs/tasks/`.
- Keep one evidence note per implementation slice.

## Canonical Naming

- File pattern: `YYYY-MM-DD_scope_slug.md`
- Example: `2026-02-21_finance-idempotency_openapi-and-migration-gates.md`

## Required Headings (Exact)

Use these headings exactly so validators stay deterministic:

1. `## Selected Skills`
2. `## Architecture Constraints`
3. `## Migration and Rollback Concerns`
4. `## Testing Scope and Gates`
5. `## Security Review Points`

## Minimum Section Completeness Rules

- `Selected Skills`: list baseline + scenario skills and one-line reason for each.
- `Architecture Constraints`: module ownership and forbidden cross-boundary behavior.
- `Migration and Rollback Concerns`: schema impact, migration order, rollback or forward-fix posture.
- `Testing Scope and Gates`: required test layers and explicit stop-the-line checks.
- `Security Review Points`: secret handling, authz/authn impact, data exposure checks.

Reject placeholders such as `TBD`, `N/A`, `-` without context, or empty sections.

## Validation Contract

A repository validator (for example `infra/scripts/validate_task_note.py`) should:

1. Detect whether the change requires evidence (default: any code, infra, or schema change).
2. Confirm at least one task note exists in `docs/tasks/`.
3. Confirm required headings exist exactly once.
4. Confirm each section has non-empty, non-placeholder content.
5. Return non-zero exit status on failure.

## Pre-Implementation Contract Alignment

The evidence headings intentionally bind to the router pre-implementation contract:

- selected skill set
- architecture/module constraints
- migration/rollback concerns
- testing scope/gates
- security/secrets review points

This keeps policy and CI checks aligned to the same structure.
