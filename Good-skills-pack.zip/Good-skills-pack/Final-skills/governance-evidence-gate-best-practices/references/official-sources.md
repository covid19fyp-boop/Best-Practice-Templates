# Official Sources

Date reviewed: 21/02/2026

## Governance And Local Enforcement Foundations

- https://git-scm.com/docs/githooks
- https://pre-commit.com/
- https://docs.docker.com/compose/

## API Contract And Compatibility Governance

- https://fastapi.tiangolo.com/how-to/extending-openapi/
- https://spec.openapis.org/oas/latest.html
- https://github.com/OpenAPITools/openapi-diff

## Migration Governance

- https://alembic.sqlalchemy.org/en/latest/autogenerate.html
- https://alembic.sqlalchemy.org/en/latest/cookbook.html
- https://www.postgresql.org/docs/current/app-pgdump.html
- https://www.postgresql.org/docs/current/app-pgrestore.html
