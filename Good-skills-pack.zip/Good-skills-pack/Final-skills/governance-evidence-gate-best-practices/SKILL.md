---
name: governance-evidence-gate-best-practices
description: Define and enforce governance evidence artifacts for every implementation task. Use when standardizing task-note contracts, validating required sections, binding selected skills and risk checks to pull-request evidence, and failing CI or hooks when evidence is missing or incomplete.
---

# Governance Evidence Gate Best Practices

Use this skill when governance needs to move from "process guidance" to "enforced evidence".

## Instructions

1. Define one canonical task-evidence location:
   - `docs/tasks/`
2. Define one canonical naming convention:
   - `YYYY-MM-DD_scope_slug.md`
3. Require these minimum headings for each task note:
   - `Selected Skills`
   - `Architecture Constraints`
   - `Migration and Rollback Concerns`
   - `Testing Scope and Gates`
   - `Security Review Points`
4. Add a deterministic validator script (for example: `infra/scripts/validate_task_note.py`) that:
   - verifies a task note exists when code changes are present
   - verifies required headings exist
   - verifies required sections are non-empty
5. Enforce validator execution in:
   - pre-commit or pre-push hooks
   - CI validation jobs
6. Fail fast when evidence is absent or incomplete.
7. Keep policy and implementation synchronized:
   - `AGENTS.md`
   - `project_structure.md`
   - governance skill docs

Use with:

- `skills/repo-governance-skill-router/SKILL.md`
- `skills/ci-cd-best-practices/SKILL.md`
- `skills/codex-cli-integration/SKILL.md`

Read:

- `references/evidence-artifact-contract.md`
- `references/official-sources.md`

## Decision Criteria

- Block implementation completion when governance evidence is missing.
- Prefer deterministic parsers over manual checklist interpretation.
- Keep required headings stable to avoid CI ambiguity.
- Keep evidence requirements minimal but non-negotiable.

## Examples

### Example 1: Introduce task evidence gate

```text
Define docs/tasks evidence format and add validator + CI job.
Fail if selected skills and risk sections are missing.
```

### Example 2: Audit weak governance adoption

```text
Audit PR history for task-note compliance.
Return pass/fail policy and missing required headings.
```

### Example 3: Harden definition-of-done

```text
Update AGENTS and project_structure docs so DoD requires evidence artifact validation.
```

## Anti-Patterns

- Keeping governance evidence as optional.
- Allowing free-form task notes without required structure.
- Checking only file existence without section completeness.
- Treating CI evidence gates as informational only.

## Checklist

- [ ] Canonical evidence path and naming are defined.
- [ ] Required task-note headings are defined and documented.
- [ ] Validator script checks presence and completeness.
- [ ] Hooks and CI run validator automatically.
- [ ] Governance docs and DoD reference evidence gate.

