---
name: codex-app-repo-workflows-best-practices
description: Operate OpenAI Codex App end-to-end for this repository with repeatable workflows. Use when onboarding this repo into Codex App, configuring project context, enabling local environments, wiring setup scripts and actions, using review/worktree/git features, tuning settings and MCP servers, or mapping Codex App features into Docker-first delivery.
---

# Codex App Repo Workflows Best Practices

Follow this workflow when using Codex App with this repository.

## 1) Start With Project Context And Governance

- Open this repository as a Codex App project.
- Ensure repository instructions are active (`AGENTS.md`, `project_structure.md`).
- Keep prompt context focused on the active slice.

Read `references/local-project-onboarding.md`.

## 2) Standardize Local Environment Startup

- Use Codex App Local Environments to skip repetitive setup.
- Keep environment setup Docker-first.
- Commit generated local-environment markdown config so future sessions share the same setup.

Read `references/local-project-onboarding.md`.

## 3) Use Setup Script And Actions Support

- Keep bootstrapping in `.codex/setup.sh`.
- Keep reusable workflows in `.codex/actions/*.md`.
- Make actions call repository scripts (`infra/scripts/ci/*.ps1`) instead of duplicating logic.

Read `references/feature-to-repo-matrix.md`.

## 4) Use Review, Worktrees, And Built-In Git Together

- Isolate each slice in a worktree/branch.
- Use Codex App review before commit/handoff.
- Use handoff links when switching between local and cloud execution.

Read `references/review-worktree-and-git-flow.md`.

## 5) Configure Settings For Safe Execution

- Keep execution mode deliberate (local for filesystem-heavy work, cloud for delegated long runs).
- Keep approval mode and sandbox strict by default, escalate only when needed.
- Connect MCP servers only when required for trusted tools and context.

Read `references/settings-security-and-mcp.md`.

## 6) Track Feature Adoption As A Matrix

- Use a feature-to-repo adoption matrix to avoid leaving Codex App features idle.
- Review matrix coverage when adding new module slices.

Read `references/feature-to-repo-matrix.md`.

## 7) Verify Before Handoff

- Run `powershell -ExecutionPolicy Bypass -File infra/scripts/ci/install-hooks.ps1` after fresh setup.
- Run `powershell -ExecutionPolicy Bypass -File infra/scripts/ci/validate-all.ps1` before completion.
- Capture findings, unresolved risks, and next actions in task notes.

For canonical updates, read `references/official-sources.md`.

## Decision Criteria

- Prefer deterministic repository scripts over ad-hoc command sequences.
- Prefer local execution for edits that require full filesystem/Docker access.
- Prefer worktree isolation for parallel tasks.
- Treat Codex App review as a release gate, not optional polish.

## Examples

### Example 1: Codex App onboarding for this repo

```text
Use $codex-app-repo-workflows-best-practices.
Set up this repository in Codex App with local environment, setup script, and validation actions.
Return exact files to create and first-run checks.
```

### Example 2: Feature slice workflow

```text
Use $codex-app-repo-workflows-best-practices.
Run a finance slice using worktree + review + commit workflow and enforce Docker-first checks.
```

### Example 3: Windows operation hardening

```text
Use $codex-app-repo-workflows-best-practices.
Tune Codex App settings for Windows 11 + Docker Desktop and document safe escalation rules.
```

## Anti-Patterns

- Running host-installed project dependencies instead of Dockerized commands.
- Skipping repository instructions and coding from generic assumptions.
- Mixing unrelated changes in one worktree.
- Auto-committing without review and validation.

## Checklist

- [ ] Project context and governance files are loaded.
- [ ] Local environment setup is reproducible and Docker-first.
- [ ] `.codex/setup.sh` and `.codex/actions/*.md` are aligned to repository scripts.
- [ ] Worktree/review/git flow is used for isolated slices.
- [ ] Settings and MCP integrations follow least-privilege defaults.
- [ ] Local CI validation is run before handoff.
