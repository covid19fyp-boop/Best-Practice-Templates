# Codex App Feature To Repo Matrix

Use this matrix to operationalize Codex App features in this repository.

| Codex App feature | How to use it in `ren` | Evidence of adoption |
| --- | --- | --- |
| Up and running in seconds | Open local project directly from `D:\Dev\Documents\GitHub\pj\ren`. | Project appears in Codex App sidebar with active thread history. |
| Project context and setup | Keep `AGENTS.md`, `project_structure.md`, and `docs/tasks/*.md` in prompt context. | New tasks reference repository governance and module boundaries. |
| Local Environments | Generate local environment config for repeatable Docker startup and checks. | Committed local environment markdown config in repo tree. |
| Setup script support | Add bootstrap commands to `.codex/setup.sh` for first-run setup (`install-hooks`, service checks). | Setup script runs without manual command copy-paste. |
| Actions support | Add `.codex/actions/*.md` for recurring flows (validate-all, targeted test suites, docs sync checks). | Actions available in Codex App and produce deterministic output. |
| Skills support | Keep specialized skills under `skills/` and trigger with `$skill-name`. | Task notes include selected skills and why they were used. |
| Threads and local work | Use one thread per slice and keep scope narrow. | Thread titles match slice intent and task notes. |
| Code review | Run Codex App review before commit/handoff. | Review findings are addressed or documented as accepted risk. |
| Built-in Git tools and PR support | Use status/diff/commit/branch inside Codex App workflow. | Commits stay scoped and traceable to slice notes. |
| Worktrees and handoff | Create one worktree per high-risk or parallel slice, handoff when moving contexts. | Handoff links map to branch/worktree names. |
| Work in cloud | Delegate long-running analysis or automation runs to cloud threads when local resources are constrained. | Cloud thread outputs linked back into local execution notes. |
| Partial checkouts for monorepos | Restrict context to touched paths (`backend/`, `frontend/`, `infra/`) for faster targeted work. | Smaller diffs and lower unrelated churn per slice. |
| Prompt snippets | Store reusable prompts for review, migration safety, and release checks. | Reused snippets reduce prompt drift across tasks. |
| Personalization | Set response style for concise engineering execution and explicit risk reporting. | Consistent output format in task and release notes. |
| Shared profiles | Use profile presets for local development vs release-hardening runs. | Profile choice is explicit in task execution evidence. |
| Voice dictation | Use for quick prompt capture while keeping final prompts explicit and auditable. | Final thread prompts stay structured despite voice entry. |
| Custom tool integration (MCP) | Connect trusted MCP servers for docs/context tools only when needed. | MCP integrations documented with trust boundary and purpose. |
| Settings (approval/sandbox) | Default to least privilege and escalate only for required operations. | Escalation events are justified in task evidence notes. |
| Command menu shortcuts | Use quick actions for common commands (search files, run action, open settings). | Faster execution with unchanged quality gates. |
| Troubleshooting guide | Use official troubleshooting paths before ad-hoc local fixes. | Incidents resolved with reproducible documented fixes. |
