# Review, Worktree, And Git Flow

## Why

- Isolate risky changes.
- Keep reviews focused.
- Support cloud/local context switching without losing progress.

## Standard Flow Per Slice

1. Create or switch to a dedicated branch/worktree for the slice.
2. Implement smallest reversible change.
3. Run targeted checks, then full local CI gate.
4. Run Codex App review and resolve findings.
5. Commit with scoped message and matching task note.
6. Use handoff when switching between local and cloud contexts.

## Worktree Naming Convention

- This repository uses the `codex/` prefix for user-created slice branches.
- Preferred pattern: `codex/<type>-<scope>-<date>`
- Example: `codex/feature-finance-ui-2026-03-08`
- For repo-specific branch/worktree decisions, load `codex-worktree-branch-slice-workflow-best-practices`.

## Commit Discipline

- One commit per coherent slice.
- Keep commit body explicit about module ownership and safety checks.
- Do not mix unrelated refactors with feature delivery.

## Handoff Discipline

- Include branch name, worktree path, and unresolved risks.
- Link to task note under `docs/tasks/`.
- Include exact validation commands already run.
- Prefer handoff over trying to keep the same branch checked out in both Local and Worktree.
