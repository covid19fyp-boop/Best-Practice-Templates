# Official Sources

Date reviewed: 05/03/2026

## OpenAI Codex App Docs

- https://developers.openai.com/codex/app
- https://developers.openai.com/codex/app/features
- https://developers.openai.com/codex/app/local-environments
- https://developers.openai.com/codex/app/review
- https://developers.openai.com/codex/app/worktrees
- https://developers.openai.com/codex/app/settings
- https://developers.openai.com/codex/app/commands
- https://developers.openai.com/codex/app/windows
- https://developers.openai.com/codex/app/troubleshooting

## OpenAI Platform Docs

- https://developers.openai.com/codex/mcp

## OpenAI Announcements And Help

- https://openai.com/index/introducing-the-codex-app/
- https://help.openai.com/en/articles/11369540-codex-in-chatgpt
