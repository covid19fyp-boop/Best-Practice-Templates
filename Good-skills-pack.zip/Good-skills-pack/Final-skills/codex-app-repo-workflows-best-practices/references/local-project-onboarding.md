# Local Project Onboarding (Windows + Docker)

## Goals

- Make Codex App project startup deterministic.
- Keep repository governance loaded by default.
- Avoid host-level dependency drift.

## Recommended Onboarding Sequence

1. Open project folder in Codex App:
   - `D:\Dev\Documents\GitHub\pj\ren`
2. Confirm Docker Desktop is running and engine is reachable:
   - `docker version`
3. Run repository hook setup:
   - `powershell -ExecutionPolicy Bypass -File infra/scripts/ci/install-hooks.ps1`
4. Start runtime stack when needed:
   - `docker compose up -d db api frontend`
5. Run full local CI gate before handoff:
   - `powershell -ExecutionPolicy Bypass -File infra/scripts/ci/validate-all.ps1`

## Local Environments Guidance

- Use Codex App Local Environments to generate markdown config in the repository (or parent directory).
- Commit that generated config so sessions share the same startup behavior.
- Keep startup flow Docker-first and call repository scripts rather than inline one-off commands.

## Windows Notes

- If repository files are in WSL, open via `\\wsl$\<distro>\<path>`.
- Keep one primary execution context per task to avoid path/shell confusion.
