# Settings, Security, And MCP

## Execution Mode

- Prefer local execution for filesystem-heavy repository work and Docker commands.
- Use cloud execution for delegated long-running analysis where local resources are constrained.

## Approval And Sandbox Posture

- Start with least-privilege settings.
- Escalate only when required by blocked commands.
- Record the reason for escalation in task evidence notes.

## Repository Context Safety

- Keep sensitive values in environment variables, not prompts.
- Avoid pasting secrets into thread messages.
- Treat logs and command output as potentially persistent artifacts.

## MCP Integration

- Connect external MCP servers only when they are trusted and required.
- Define purpose and data boundary before enabling any server.
- Disable unused MCP servers to reduce accidental data exposure.

## Profile Strategy

- Keep separate profiles for:
  - fast local iteration
  - full release-hardening checks
- Make profile selection explicit per task.
