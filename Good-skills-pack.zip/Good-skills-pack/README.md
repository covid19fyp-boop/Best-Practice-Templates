# Skill Share Bundle

This folder is a shareable snapshot of the repository-local skills from `ren`.

Generated: 12/03/2026 20:35
Included skill directories: 51

## How to use

1. Copy `AGENTS.md` and the `skills/` folder from this bundle into the target repository root.
2. Keep this repository's canonical skill source in `skills/` and its canonical governance file in `AGENTS.md`.
3. Refresh this bundle by running:
   `powershell -ExecutionPolicy Bypass -File infra/scripts/export-skills-share-bundle.ps1`
4. Optionally sync the repo skills into the current user's global Codex skills directory by running:
   `powershell -ExecutionPolicy Bypass -File infra/scripts/export-skills-share-bundle.ps1 -CopyToGlobal`

## Included skills

- `alembic-migration-best-practices`
- `api-contract-versioning-best-practices`
- `architecture-modular-monolith`
- `architecture-splitting-strategy`
- `attachment-best-practices`
- `auth-best-practices`
- `background-jobs-best-practices`
- `backup-restore-best-practices`
- `business-rule-module-best-practices`
- `ci-cd-best-practices`
- `codex-app-automation-best-practices`
- `codex-app-repo-workflows-best-practices`
- `codex-cli-hook-best-practices`
- `codex-cli-integration`
- `codex-cli-windows11-vscode-best-practices`
- `codex-research-best-practices`
- `codex-rfc-codebase-research`
- `codex-worktree-branch-slice-workflow-best-practices`
- `database-and-migrations`
- `docker-best-practices`
- `error-solution-best-practices`
- `fastapi-best-practices`
- `feature-flag-release-best-practices`
- `finance-frontend-ui-ux-best-practices`
- `finance-module-best-practices`
- `fullstack-fastapi-nextjs-postgres-docker`
- `git-windows-best-practices`
- `good-app-best-practices`
- `governance-evidence-gate-best-practices`
- `local-ci-enforcement-best-practices`
- `maintenance-current-stack-best-practices`
- `malaysia-format-english-fullstack`
- `modern-ui-ux-best-practices`
- `module-consistency-best-practices`
- `nextjs-best-practices`
- `observability-best-practices`
- `performance-load-testing-best-practices`
- `postgres-docker-best-practices`
- `pwa-best-practices`
- `release-and-versioning`
- `repo-governance-skill-router`
- `repo-structure-and-conventions`
- `sdlc-codex-cli-best-practices`
- `sdlc-personal-dev`
- `security-and-secrets`
- `security-best-practices`
- `skill-best-practices`
- `soft-delete-best-practices`
- `technical-debt-controls`
- `testing-best-practices-codex`
- `testing-strategy`
